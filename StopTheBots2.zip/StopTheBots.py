# ba_meta require api 9
from __future__ import annotations

import random
from typing import Type

import bascenev1 as bs
from bascenev1lib.actor.scoreboard import Scoreboard
from bascenev1lib.actor.spazbot import (
    SpazBotSet,
    BomberBot, ToughGuyBot, ChickBot,
    ChickBotPro, ChickBotProShielded,
    BomberBotProShielded,
    NinjaBot, NinjaBotProShielded,
    MelBot, PirateBot,
    ToughGuyBotProShielded
)
from bascenev1lib.actor.bomb import Bomb


# ba_meta export game
class StopTheBots(bs.CoopGameActivity[bs.Player, bs.Team]):

    name = 'Stop The Bots'
    description = 'Prevent enemies from reaching the red line.'

    @classmethod
    def get_supported_maps(cls, sessiontype: Type[bs.Session]) -> list[str]:
        return ['Stop']

    def __init__(self, settings: dict):
        super().__init__(settings)

        self._wave = 0
        self._score = 0
        self._game_over = False

        self._bot_set = SpazBotSet()
        self._scoreboard = Scoreboard()

        # BONUS
        self._time_bonus = 0
        self._bonus_timer = None
        self._bonus_text = None

        # TNT
        self._tnt_spawn_position = self.map.defs.points['tntLoc'][0:3]
        self._tnt: Bomb | None = None

    # --------------------------------------------------
    # START
    # --------------------------------------------------

    def on_transition_in(self) -> None:
        super().on_transition_in(music='ToTheDeath')

    def on_begin(self) -> None:
        super().on_begin()
        self._setup_end_region()
        self._start_bot_movement()
        self._start_next_wave()

    # --------------------------------------------------
    # WAVES
    # --------------------------------------------------

    def _start_next_wave(self) -> None:
        if self._game_over:
            return

        self._wave += 1

        bs.screenmessage(f'Wave {self._wave}', color=(1, 1, 0))

        self._time_bonus = 100 + (self._wave * 20)
        self._update_bonus_text()
        self._start_bonus_timer()

        self._spawn_tnt()

        bs.timer(2.0, self._spawn_wave)

    def _spawn_wave(self) -> None:

        level = self._wave
        target_points = (level + 1) * 8.0

        bot_pool = []

        if level < 6:
            bot_pool += [BomberBot]
        if level < 10:
            bot_pool += [ToughGuyBot]
        if level < 15:
            bot_pool += [ChickBot]
        if level > 5:
            bot_pool += [ChickBotPro] * (1 + (level - 5) // 7)
        if level > 2:
            bot_pool += [BomberBotProShielded] * (1 + (level - 2) // 6)
        if level > 6:
            bot_pool += [ChickBotProShielded] * (1 + (level - 6) // 5)
        if level > 1:
            bot_pool += [NinjaBot] * (1 + (level - 1) // 4)
        if level > 7:
            bot_pool += [NinjaBotProShielded] * (1 + (level - 7) // 3)

        if not bot_pool:
            bot_pool = [BomberBot]

        spawn_count = min(len(bot_pool), int(target_points // 2))

        for _ in range(spawn_count):
            bot_class = random.choice(bot_pool)
            self._bot_set.spawn_bot(
                bot_class,
                pos=self.map.get_start_position(0),
                spawn_time=0.0
            )

    # --------------------------------------------------
    # MOVEMENT FORCED
    # --------------------------------------------------

    def _start_bot_movement(self) -> None:
        bs.timer(0.1, self._update_bot_movement, repeat=True)

    def _update_bot_movement(self) -> None:
        if self._game_over:
            return

        for bot in self._bot_set.get_living_bots():
            if bot.node:
                bot.node.move_left_right = 1.0

    # --------------------------------------------------
    # END REGION
    # --------------------------------------------------

    def _setup_end_region(self) -> None:

        self._end_material = bs.Material()

        self._end_material.add_actions(
            conditions=('they_have_material', bs.SpazBot.get_material()),
            actions=(('call', 'at_connect', self._bot_reached_end),)
        )

        self._end_region = bs.newnode(
            'region',
            attrs={
                'position': (7.0, 0.5, 0.0),
                'scale': (0.4, 4.5, 6.0),
                'type': 'box',
                'materials': [self._end_material]
            }
        )

    def _bot_reached_end(self) -> None:
        node = bs.getcollision().opposingnode
        actor = node.getdelegate(object)

        if not actor:
            return

        self._score -= 5
        self._update_scoreboard()
        actor.handlemessage(bs.DieMessage())

    # --------------------------------------------------
    # BONUS
    # --------------------------------------------------

    def _start_bonus_timer(self) -> None:
        bs.timer(1.0, self._decrease_bonus, repeat=True)

    def _decrease_bonus(self) -> None:
        if self._time_bonus > 0:
            self._time_bonus -= 5
            self._update_bonus_text()

    def _update_bonus_text(self) -> None:

        color = (1, 1, 0)
        if self._time_bonus < 50:
            color = (1, 0.5, 0)
        if self._time_bonus < 25:
            color = (1, 0, 0)

        if not self._bonus_text:
            self._bonus_text = bs.NodeActor(
                bs.newnode(
                    'text',
                    attrs={
                        'v_attach': 'top',
                        'h_attach': 'center',
                        'h_align': 'center',
                        'v_align': 'top',
                        'position': (0, -60),
                        'scale': 1.4,
                        'text': '',
                        'shadow': 1.0,
                        'flatness': 1.0,
                    }
                )
            )

        self._bonus_text.node.text = f'Bonus: {self._time_bonus}'
        self._bonus_text.node.color = color

    # --------------------------------------------------
    # TNT
    # --------------------------------------------------

    def _spawn_tnt(self) -> None:
        if self._tnt and self._tnt.node and self._tnt.node.exists():
            return

        self._tnt = Bomb(
            position=self._tnt_spawn_position,
            bomb_type='tnt'
        )

    # --------------------------------------------------
    # DEATH / SCORE
    # --------------------------------------------------

    def handlemessage(self, msg: object) -> object:

        if isinstance(msg, bs.SpazBotDeathMessage):

            self._score += 10
            self._update_scoreboard()

            if not self._bot_set.have_living_bots():

                self._score += self._time_bonus
                self._update_scoreboard()

                bs.screenmessage(
                    f'Wave Bonus: {self._time_bonus}',
                    color=(0, 1, 0)
                )

                bs.timer(3.0, self._start_next_wave)

        return super().handlemessage(msg)

    def _update_scoreboard(self) -> None:
        if self.teams:
            self._scoreboard.set_team_value(self.teams[0], self._score)

    def end_game(self) -> None:
        self._game_over = True
        results = bs.GameResults()
        results.set_team_score(self.teams[0], self._score)
        self.end(results)