# ba_meta export game
class StopTheBots(bs.CoopGameActivity[bs.Player, bs.Team]):

    name = "Stop The Bots"
    description = "Sobrevive a las oleadas de bots."

    @classmethod
    def get_supported_maps(cls, sessiontype: type[bs.Session]) -> list[str]:
        return ["Football Stadium"]

    @classmethod
    def supports_session_type(cls, sessiontype: type[bs.Session]) -> bool:
        return issubclass(sessiontype, bs.CoopSession)

    def __init__(self, settings: dict):
        super().__init__(settings)

        self._bots = SpazBotSet()
        self._scoreboard = Scoreboard()
        self._wave = 0
        self._lives = 3
        self._score = 0
        self._wave_in_progress = False

    def on_begin(self) -> None:
        super().on_begin()
        self._update_scoreboard()
        self._start_wave()

    # ------------------------------------------------
    # WAVE SYSTEM
    # ------------------------------------------------

    def _start_wave(self) -> None:
        if self._wave_in_progress:
            return

        self._wave += 1
        self._wave_in_progress = True
        self._spawn_wave()

    def _spawn_wave(self) -> None:
        bot_types = [
            BomberBot,
            BomberBotPro,
            BrawlerBot,
            ChargerBot,
            TriggerBot,
        ]

        # Spawn lado izquierdo del mapa
        for _ in range(self._wave + 2):
            bot_type = random.choice(bot_types)
            pos = (-11, 1, random.uniform(-4, 4))
            self._bots.spawn_bot(bot_type, pos=pos)

    def _check_wave_end(self) -> None:
        if not self._bots.have_living_bots():
            self._wave_in_progress = False
            bs.timer(2.0, self._start_wave)

    # ------------------------------------------------
    # PLAYER HANDLING
    # ------------------------------------------------

    def spawn_player(self, player: bs.Player) -> bs.Actor:
        return self.spawn_player_spaz(player, position=(8, 1, 0))

    def handlemessage(self, msg: bs.Message) -> None:

        if isinstance(msg, bs.PlayerDiedMessage):
            super().handlemessage(msg)

            self._lives -= 1
            self._update_scoreboard()

            if self._lives <= 0:
                self.end_game()
            else:
                bs.timer(2.0, lambda: self.spawn_player(msg.getplayer(bs.Player)))

        else:
            super().handlemessage(msg)

        # Revisar si terminó la ronda
        self._check_wave_end()

    # ------------------------------------------------
    # SCORE + END
    # ------------------------------------------------

    def _update_scoreboard(self) -> None:
        for team in self.teams:
            self._scoreboard.set_team_value(team, self._score)

    def end_game(self) -> None:
        results = bs.GameResults()
        for team in self.teams:
            results.set_team_score(team, self._score)
        self.end(results)