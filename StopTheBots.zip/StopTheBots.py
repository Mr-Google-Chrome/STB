# ba_meta require api 9
from __future__ import annotations

import random
import bascenev1 as bs
import babase

from bascenev1lib.actor.scoreboard import Scoreboard
from bascenev1lib.actor.spazbot import (
    SpazBotSet,
    BomberBot,
    BomberBotPro,
    BrawlerBot,
    ChargerBot,
    TriggerBot,
)


# ba_meta export game
class StopTheBots(bs.CoopGameActivity[bs.Player, bs.Team]):

    name = "Stop The Bots"
    description = "Sobrevive a las oleadas de bots."

    @classmethod
    def get_supported_maps(cls, sessiontype: type[bs.Session]) -> list[str]:
        return ["Football Stadium"]

    @classmethod
    def supports_session_type(cls, sessiontype: type[bs.Session]) -> bool:
        return issubclass(sessiontype, bs.CoopSession)

    def __init__(self, settings: dict):
        super().__init__(settings)

        self._bots = SpazBotSet()
        self._scoreboard = Scoreboard()
        self._bot_force_timer: bs.Timer | None = None
        self._wave = 0
        self._wave_active = False
        self._score = 0

    # ------------------------------------------------
    # INICIO
    # ------------------------------------------------

    def on_begin(self) -> None:
        super().on_begin()

        self._update_scoreboard()
        self._start_wave()

        # Verificador continuo de fin de ronda
        self._wave_check_timer = bs.Timer(
            0.5,
            self._check_wave_end,
            repeat=True
        )
        # Sistema de movimiento forzado
        self._bot_force_timer = bs.Timer(
            0.1,
            self._update_bots_movement,
            repeat=True
        )

    # ------------------------------------------------
    # SISTEMA DE RONDAS
    # ------------------------------------------------

    def _start_wave(self) -> None:
        if self._wave_active:
            return

        self._wave += 1
        self._wave_active = True
        self._spawn_wave()

    def _spawn_wave(self) -> None:
        bot_types = [
            BomberBot,
            BomberBotPro,
            BrawlerBot,
            ChargerBot,
            TriggerBot,
        ]

        # Spawn lado izquierdo
        for _ in range(self._wave + 2):
            bot_type = random.choice(bot_types)
            pos = (-11, 1, random.uniform(-4, 4))
            self._bots.spawn_bot(bot_type, pos=pos)

    def _check_wave_end(self) -> None:
        if self._wave_active and not self._bots.have_living_bots():
            self._wave_active = False
            self._start_wave()

    # ------------------------------------------------
    # BOTS MOTION
    # ------------------------------------------------

    def _update_bots_movement(self) -> None:

        for bot in
    self._bots.get_living_bots():

            if not bot.node:
                continue

            # Forzar movimiento hacia la derecha
            bot.node.move_left_right = 1.0
            bot.node.move_up_down = 0.0

            # Cancelar acciones
            bot.node.jump_pressed = False
            bot.node.pickup_pressed = False
            bot.node.punch_pressed = False
            bot.node.bomb_pressed = False

            # TriggerBot puede correr
            if bot.__class__.__name__ == "TriggerBot":
                bot.node.run = 1.0
            else:
                bot.node.run = 0.0

            # Zona de eliminación (lado derecho)
            if bot.node.position[0] > 10.5:
                bot.node.delete()

    # ------------------------------------------------
    # PLAYER
    # ------------------------------------------------

    def spawn_player(self, player: bs.Player) -> bs.Actor:
        return self.spawn_player_spaz(player, position=(8, 1, 0))

    def handlemessage(self, msg: bs.Message) -> None:

        if isinstance(msg, bs.PlayerDiedMessage):
            super().handlemessage(msg)

            # Respawn infinito
            bs.timer(
                1.0,
                lambda: self.spawn_player(msg.getplayer(bs.Player))
            )
            return

        super().handlemessage(msg)

        # Revisar si terminó la ronda
        self._check_wave_end()

    # ------------------------------------------------
    # SCORE
    # ------------------------------------------------

    def _update_scoreboard(self) -> None:
        for team in self.teams:
            self._scoreboard.set_team_value(team, self._score)


# ba_meta export babase.Plugin
class StopBotsPlugin(babase.Plugin):

    def on_app_running(self) -> None:
        classic = babase.app.classic
        if classic is None:
            return

        classic.add_coop_practice_level(
            bs.Level(
                name="Stop The Bots",
                gametype=StopTheBots,
                settings={},
                preview_texture_name="footballStadiumPreview",
            )
        )