# ba_meta require api 9
from __future__ import annotations

import random
import bascenev1 as bs
import babase

from bascenev1lib.actor.scoreboard import Scoreboard
from bascenev1lib.actor.spazbot import (
    SpazBotSet,
    BomberBot,
    BomberBotPro,
    BrawlerBot,
    ChargerBot,
    TriggerBot,
)


# ba_meta export game
class StopTheBots(bs.CoopGameActivity[bs.Player, bs.Team]):

    name = "Stop The Bots"
    description = "Sobrevive a las oleadas de bots."

    @classmethod
    def get_supported_maps(cls, sessiontype: type[bs.Session]) -> list[str]:
        return ["Football Stadium"]

    @classmethod
    def supports_session_type(cls, sessiontype: type[bs.Session]) -> bool:
        return issubclass(sessiontype, bs.CoopSession)

    def __init__(self, settings: dict):
        super().__init__(settings)

        self._bots = SpazBotSet()
        self._scoreboard = Scoreboard()
        self._bot_force_timer: bs.Timer | None = None
        self._wave_check_timer: bs.Timer | None = None

        self._wave = 0
        self._wave_active = False
        self._score = 0

    # ------------------------------------------------
    # INICIO
    # ------------------------------------------------

    def on_begin(self) -> None:
        super().on_begin()

        self._update_scoreboard()
        self._start_wave()

        # Verificador continuo de fin de ronda
        self._wave_check_timer = bs.Timer(
            0.5,
            self._check_wave_end,
            repeat=True
        )

        # Movimiento forzado
        self._bot_force_timer = bs.Timer(
            0.1,
            self._update_bots_movement,
            repeat=True
        )

    # ------------------------------------------------
    # SISTEMA DE RONDAS
    # ------------------------------------------------

    def _start_wave(self) -> None:
        if self._wave_active:
            return

        self._wave += 1
        self._wave_active = True
        self._spawn_wave()

    def _spawn_wave(self) -> None:
        bot_types = [
            BomberBot,
            BomberBotPro,
            BrawlerBot,
            ChargerBot,
            TriggerBot,
        ]

        for _ in range(self._wave + 2):
            bot_type = random.choice(bot_types)
            pos = (-11, 1, random.uniform(-4, 4))
            self._bots.spawn_bot(bot_type, pos=pos)

    def _check_wave_end(self) -> None:
        if self._wave_active and not self._bots.have_living_bots():
            self._wave_active = False
            self._start_wave()

    # ------------------------------------------------
    # BOTS MOTION
    # ------------------------------------------------

    def _update_bots_movement(self) -> None:

        for bot in self._bots.get_living_bots():

            if not bot.node:
                continue

            # Quitar objetivo jugador
            bot.set_player_target(None)

            # Punto meta hacia la derecha
            target_pos = (20, bot.node.position[1], bot.node.position[2])

            # Forzar que camine hacia ese punto
            bot.set_move_target(target_pos)

            # Desactivar comportamiento agresivo
            bot.target = None

            # Permitir correr solo a ChargerBot
            if bot.__class__.__name__ == "ChargerBot":
                bot.node.run = 1.0
            else:
                bot.node.run = 0.0

            # Zona de eliminación
            if bot.node.position[0] > 10.5:
                bot.node.delete()

    # ------------------------------------------------
    # PLAYER
    # ------------------------------------------------

    def spawn_player(self, player: bs.Player) -> bs.Actor:
        return self.spawn_player_spaz(player, position=(8, 1, 0))

    def handlemessage(self, msg: bs.Message) -> None:

        if isinstance(msg, bs.PlayerDiedMessage):
            super().handlemessage(msg)

            bs.timer(
                1.0,
                lambda: self.spawn_player(msg.getplayer(bs.Player))
            )
            return

        super().handlemessage(msg)

    # ------------------------------------------------
    # SCORE
    # ------------------------------------------------

    def _update_scoreboard(self) -> None:
        for team in self.teams:
            self._scoreboard.set_team_value(team, self._score)


# ba_meta export babase.Plugin
class StopBotsPlugin(babase.Plugin):

    def on_app_running(self) -> None:
        classic = babase.app.classic
        if classic is None:
            return

        classic.add_coop_practice_level(
            bs.Level(
                name="Stop The Bots",
                gametype=StopTheBots,
                settings={},
                preview_texture_name="footballStadiumPreview",
            )
        )