# ba_meta require api 9
# ba_meta export map

from __future__ import annotations
import bascenev1 as bs
from bascenev1lib.map import Map
from . import stopDefs


class Stop(Map):
    name = 'Stop'
    defs = stopDefs

    @classmethod
    def get_play_types(cls) -> list[str]:
        return ['coop']